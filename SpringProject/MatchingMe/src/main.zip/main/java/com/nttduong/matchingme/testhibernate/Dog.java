package com.nttduong.matchingme.testhibernate;

public class Dog extends Animal {
	
	@Override
	public void Sound() {
		System.out.println("Gaw Gaw");
	}
}
