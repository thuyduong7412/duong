package com.nttduong.matchingme.testhibernate;

public class Cat extends Animal {

	@Override
	public void Sound() {
		System.out.println("Meo Meo");
		
	}

}
