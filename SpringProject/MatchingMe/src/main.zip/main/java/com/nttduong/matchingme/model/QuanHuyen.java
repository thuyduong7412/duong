package com.nttduong.matchingme.model;

public class QuanHuyen {
	private int maqh;
	private String name;
	private String type;
	private String matp;

	public int getMaqh() {
		return maqh;
	}

	public void setMaqh(int maqh) {
		this.maqh = maqh;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getMatp() {
		return matp;
	}

	public void setMatp(String matp) {
		this.matp = matp;
	}
}
